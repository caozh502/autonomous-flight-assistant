//
// Created by caleb on 10.05.21.
//

#include "CollisionDetection.h"

Box createBox(Eigen::Vector3f uav_point, float width, float length, float height){
    Box uav;
    uav.x_min=uav_point(0);
    uav.x_max=uav_point(0)+width;
    uav.y_min=uav_point(1);
    uav.y_max=uav_point(1)+height;
    uav.z_min=uav_point(2)-length;
    uav.z_max=uav_point(2);
    return uav;
}

Eigen::Matrix3f collision_detection::setRPY(Eigen::Vector3f rot){
    Eigen::Matrix3f ret;
    ret = Eigen::AngleAxisf(rot.x(), Eigen::Vector3f::UnitX())
          * Eigen::AngleAxisf(rot.y(), Eigen::Vector3f::UnitY())
          * Eigen::AngleAxisf(rot.z(), Eigen::Vector3f::UnitZ());
    return ret;
}

fcl::CollisionObjectf collision_detection::createCollisionObject(pcl::PointCloud<pcl::PointXYZ>::Ptr pointcloud_ptr){
    // octomap octree settings
    const float resolution = 0.1;
    const float prob_hit = 0.9;
    const float prob_miss = 0.1;
    const float clamping_thres_min = 0.12;
    const float clamping_thres_max = 0.98;
    octomap::point3d sensor_origin_3d (0.,0.,0.);

    std::shared_ptr<octomap::OcTree> octomap_octree = std::make_shared<octomap::OcTree>(resolution);
    octomap_octree->setProbHit(prob_hit);
    octomap_octree->setProbMiss(prob_miss);
    octomap_octree->setClampingThresMin(clamping_thres_min);
    octomap_octree->setClampingThresMax(clamping_thres_max);
    octomap::Pointcloud octoCloud;
    for(pcl::PointCloud<pcl::PointXYZ>::iterator it = pointcloud_ptr->begin(); it < pointcloud_ptr->end(); ++it)
    {
        octoCloud.push_back(octomap::point3d(it->x, it->y,it->z));
    }
    octomap_octree->insertPointCloud(octoCloud, sensor_origin_3d, -1, true, true);
    octomap_octree->updateInnerOccupancy();

    auto fcl_octree = std::make_shared<fcl::OcTreef> (octomap_octree);
    return fcl::CollisionObjectf (fcl_octree);
}
//bool isCollision(Box box, Box uav){
//    //auto startTime = std::chrono::steady_clock::now();
//
//
//    if (box.x_min <= uav.x_max && box.x_max >= uav.x_min)
//        if  (box.y_min <= uav.y_max && box.y_max >= uav.y_min)
//
//            return (box.z_min <= uav.z_max && box.z_max >= uav.z_min);
//
////    auto endTime = std::chrono::steady_clock::now();
////    auto elapsedTime = std::chrono::duration_cast<std::chrono::milliseconds>(endTime - startTime);
////    std::cout << "Collision Detection took " << elapsedTime.count() << " ms" << std::endl;
//    return false;
//
//}

void CollisionVisualization(pcl::visualization::PCLVisualizer::Ptr& viewer, Box box, Color color,int id){
    std::string cube = "uav"+std::to_string(id);
    viewer->addCube(box.x_min, box.x_max, box.y_min, box.y_max, box.z_min, box.z_max, color.r, color.g, color.b, cube);
    viewer->setShapeRenderingProperties(pcl::visualization::PCL_VISUALIZER_REPRESENTATION, pcl::visualization::PCL_VISUALIZER_REPRESENTATION_SURFACE, cube);
}

void UAVBoxVisualization(pcl::visualization::PCLVisualizer::Ptr& viewer, Box box, Color color,int id){
    std::string cube = "uavBox"+std::to_string(id);
    viewer->removeShape("uavBox"+std::to_string(id));
    viewer->addCube(box.x_min, box.x_max, box.y_min, box.y_max, box.z_min, box.z_max, color.r, color.g, color.b, cube);
    viewer->setShapeRenderingProperties(pcl::visualization::PCL_VISUALIZER_REPRESENTATION, pcl::visualization::PCL_VISUALIZER_REPRESENTATION_WIREFRAME, cube);
}

collision_detection::collision_detection(const PtCdtr &cluster, float width, float length, float height){
    auto startTime = std::chrono::steady_clock::now();

    boost::shared_ptr<pcl::PointCloud<pcl::PointXYZ>> cloudCluster(new pcl::PointCloud<pcl::PointXYZ>);
    if (cluster->empty()) {
        return;
    }
    pcl::copyPointCloud(*cluster, *cloudCluster);
    auto octree_point = createCollisionObject(cloudCluster);
    std::shared_ptr<fcl::CollisionGeometryf> box_geometry1(new fcl::Boxf(width,height,length));
    fcl::CollisionObjectf box1(box_geometry1);

    fcl::Vector3f trans1(0.,0.,0.);
    fcl::Vector3f rot1(0.,0.,0.);
    fcl::Vector3f trans2(0.,0.,0.);
    fcl::Vector3f rot2(0.,0.,0.);
    box1.setTranslation(trans1);
    box1.setRotation(setRPY(rot1));
    octree_point.setTranslation(trans2);
    octree_point.setRotation(setRPY(rot2));
    // DynamicAABBTree BroadPhase Managers
    std::shared_ptr<fcl::BroadPhaseCollisionManager<float>> group1 = std::make_shared<fcl::DynamicAABBTreeCollisionManager<float>>();

    // Set Objects
    group1->registerObject(&octree_point);
    group1->setup();

    // Data store
    fcl::DefaultDistanceData<float> d_data1;
    fcl::DefaultCollisionData<float> c_data1;


    // 1. Contact Number between env and que
    //group1->collide(&box1, &c_data1, fcl::DefaultCollisionFunction);
    group1->distance(&box1, &d_data1, fcl::DefaultDistanceFunction);
    //bool res = c_data1.result.isCollision();
    min_distance = d_data1.result.min_distance;
    //std::cout << res << std::endl;
//    request.enable_nearest_points = true;
//    request.enable_signed_distance = true;
//    request.gjk_solver_type = fcl::GJKSolverType::GST_INDEP;
//    //request.gjk_solver_type = fcl::GJKSolverType::GST_LIBCCD;
//
//    // Calculate distance
//    result.clear();
//    //fcl::collide(&box1, &octree_point,C_request,C_result);
//    fcl::distance(&box1, &octree_point, request, result);
//    min_distance = result.min_distance;

    auto endTime = std::chrono::steady_clock::now();
    auto elapsedTime = std::chrono::duration_cast<std::chrono::milliseconds>(endTime - startTime);
    ROS_INFO_STREAM( "Collision Detection took " << elapsedTime.count() << " ms");
}
collision_detection::collision_detection(Box obj,Box drone){
    float drone_w = drone.x_max-drone.x_min;
    float drone_h = drone.y_max-drone.y_min;
    float drone_l = drone.z_max-drone.z_min;
//    std::cout<<drone_w<<" "<<drone_h <<" "<<drone_l<<" "<<std::endl;

    float obj_w = obj.x_max-obj.x_min;
    float obj_h = obj.y_max-obj.y_min;
    float obj_l = obj.z_max-obj.z_min;
//    std::cout<<obj_w<<" "<<obj_h <<" "<<obj_l<<" "<<std::endl;
    //center of object
    float objc_x = (obj.x_max+obj.x_min)/2.;
    float objc_y = (obj.y_max+obj.y_min)/2.;
    float objc_z = (obj.z_max+obj.z_min)/2.;
//    std::cout<<objc_x<<" "<<objc_y <<" "<<objc_z<<" "<<std::endl;

    std::shared_ptr<fcl::CollisionGeometryf> drone_geometry(new fcl::Boxf(drone_w,drone_h,drone_l));
    fcl::CollisionObjectf box1(drone_geometry);
    std::shared_ptr<fcl::CollisionGeometryf> obj_geometry(new fcl::Boxf(obj_w,obj_h,obj_l));
    fcl::CollisionObjectf box2(obj_geometry);

    fcl::Vector3f trans1(0.,0.,0.);
    fcl::Vector3f rot1(0.,0.,0.);
    fcl::Vector3f trans2(objc_x,objc_y,objc_z);
    fcl::Vector3f rot2(0.,0.,0.);
    box1.setTranslation(trans1);
    box1.setRotation(setRPY(rot1));
    box2.setTranslation(trans2);
    box2.setRotation(setRPY(rot2));

    request.enable_nearest_points = true;
    request.enable_signed_distance = true;
    request.gjk_solver_type = fcl::GJKSolverType::GST_INDEP;
    //request.gjk_solver_type = fcl::GJKSolverType::GST_LIBCCD;

    // Calculate distance
    result.clear();
    //fcl::collide(&box1, &box2,C_request,C_result);
    fcl::distance(&box1, &box2, request, result);
    min_distance = result.min_distance;
}
collision_detection::~collision_detection(){}