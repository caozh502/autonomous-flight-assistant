#ifndef ARDRONE_ROS_H
#define ARDRONE_ROS_H

#include <ros/ros.h>
#include <std_msgs/Empty.h>
#include <std_msgs/Bool.h>
#include <sensor_msgs/Joy.h>
#include <dji_sdk/DroneTaskControl.h>
#include <dji_sdk/SDKControlAuthority.h>
#include <djiosdk/dji_version.hpp>
#include <std_msgs/UInt8.h>
#include "dji_sdk/dji_sdk.h"



/**
 * @brief A simple class to send the commands to the drone through 
 * the corresponding topics
 */

class DroneObjectROS{
protected:
    DroneObjectROS(){}
public:
    
    DroneObjectROS(ros::NodeHandle& node){
        initROSVars(node);
    }

    bool isFlying;
    bool isPosctrl;

    uint8_t flight_status = 255;
    uint8_t display_mode  = 255;

    uint8_t joy_cmd_flag;
    
    ros::Publisher pubTakeOff;
    ros::Publisher pubLand;
    ros::Publisher pubCmd;

    ros::ServiceClient drone_task_service;
    ros::ServiceClient sdk_ctrl_authority_service;

    void initROSVars(ros::NodeHandle& node);

    bool takeoff_land(int task);
    bool monitoredTakeoff();
    void display_mode_callback(const std_msgs::UInt8::ConstPtr& msg);

    void flight_status_callback(const std_msgs::UInt8::ConstPtr& msg);


    void takeOff();
    void land();
    void hover();

    // commands for controling ARDrone
    // pitch_lr = left-right tilt		(-1) to right		(+1)
    // roll_fb = front-back tilt 		(-1) to backwards	(+1)
    // v_du = velocity downwards	(-1) to upwards		(+1)
    // w_lr = angular velocity left (-1) to right		(+1)

    void pitch(float speed);
    void pitch_l45(float speed);
    void pitch_r45(float speed);
    void pitch_l30(float speed);
    void pitch_r30(float speed);
    void roll(float speed);
    void rise(float speed);
    void yaw(float speed);
    void move(float s_1, float s_2, float s_3, float s_4);



};

#endif // ARDRONE_ROS_H
