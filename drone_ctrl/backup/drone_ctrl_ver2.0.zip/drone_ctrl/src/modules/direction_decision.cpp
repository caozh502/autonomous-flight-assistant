//
// Created by caleb on 17.05.21.
//

#include "direction_decision.h"

//#define C_EARTH (double)6378137.0
#define C_PI (double)3.141592653589793
//#define DEG2RAD(DEG) ((DEG) * ((C_PI) / (180.0)))
const int color_bar[][3] =
        {
                { 255,0,0},
                { 0,255,0 },
                { 0,0,255 },
                { 0,255,255 },
                { 255,255,0 },
                { 255,255,255 },
                { 255,0,255 }
        };
//TODO: cloudClusters in message rewrite (reference drone_object_ros.cpp)
std::vector<PtCdtr> cloudClusters;
pcl::visualization::PCLVisualizer::Ptr viewer;
//Mission square_mission;

// global variables for subscribed topics



direction_decision::direction_decision(DroneObjectROS &drone)
    : nh(), gpsSub(), my_drone(drone),
    target_x(0.0), target_y(0.0), target_z(0.0),
    drone_x(0.0), drone_y(0.0), drone_z(0.0), drone_yaw(0.0)
{
    attiSub = nh.subscribe("dji_sdk/attitude", 1, &direction_decision::attitude_callback,this);
    gpsSub = nh.subscribe("dji_sdk/gps_position", 1, &direction_decision::motionStep,this);
    setTarget(49.01348,8.40670,-9.70000);
}


direction_decision::~direction_decision(){}

void direction_decision::motionStep(const sensor_msgs::NavSatFix::ConstPtr& msg) {

    ////get Angle between drone heading vector and drone2Target vector
    current_gps = *msg;
    if (optGPS == 0) {
        init_gps = *msg;
        optGPS =1;
        ROS_INFO("initial altitude: %.5f", init_gps.altitude);
    }

    ROS_INFO("GPS: lat=%.5f, long=%.5f, alti=%.5f", msg->latitude, msg->longitude, msg->altitude);
    setDronePos(current_gps.latitude,current_gps.longitude,current_gps.altitude,
                toEulerAngle(current_atti).z);
    //angle_ro: angle for drone to aim to target
    float angle_ro=getAimAngle();
    ROS_INFO("you need rotate %.5f rad, yawRad = %.5f", angle_ro, drone_yaw);

    ////TODO: turn to target (just at very beginning)
    //drone_rotation(angle_ro);

    int clusterId = 0;
    int obs_state = 0;
    ///drone variables
    Eigen::Vector3f uav_point(-1, -0.5, 1.5);
    float length = 2 * uav_point(2);
    float width = -2 * uav_point(0);
    float height = -2 * uav_point(1);
//    std::cout<<width<<" "<<length <<" "<<height<<" "<<std::endl;

    Box droneBox = createBox(uav_point, width, length, height);

    UAVBoxVisualization(viewer, droneBox, colors[1], clusterId);

    if (cloudClusters.empty()){
        //std::cout<<"cannot get clusters!"<<std::endl;
        drone_forward(0.02);
        clusterId++;
        return;
    }

    for (const PtCdtr &cluster : cloudClusters) {

        pcl::visualization::PointCloudColorHandlerCustom<PointT> cloud_in_color_h(cluster,
                                                                                  color_bar[clusterId][0],
                                                                                  color_bar[clusterId][1],
                                                                                  color_bar[clusterId][2]);//赋予显示点云的颜色
//        pcl::visualization::PointCloudColorHandlerRandom<PointT> cloud_in_color_h(cluster);
        viewer->addPointCloud<PointT>(cluster, cloud_in_color_h, "cluster" + std::to_string(clusterId));

        /// 4th: Find bounding boxes for each obstacle cluster
        Box box = BoundingBox(cluster);
        renderBox(viewer, box, clusterId);

        /// 5th: Collision Detection && Direction Decision
        //Rough detection
        collision_detection CD_Rough(box,droneBox);
        ROS_INFO_STREAM("Rough min_distance is " << CD_Rough.min_distance);
       if (CD_Rough.min_distance < (2*d_safe)){
            //Fine detection
            collision_detection CD(cluster, width, length, height);

            ROS_INFO_STREAM( "Fine min_distance is " << CD.min_distance);
            if (CD.min_distance<d_safe) {
                ROS_INFO( "***** There is obstacle in the range *****" );
                viewer->removeShape("uav" + std::to_string(clusterId-1));
                CollisionVisualization(viewer, droneBox, colors[0], clusterId);

                motionCtrl(box, width, length, height);
                //drone_stop(1);
                clusterId++;
                obs_state = 1;
                return;
            }
        }
        clusterId++;
        ////TODO: turn to target again, go ahead
    }
    ROS_INFO("***** There is no obstacle in the range *****");
    if (obs_state==0) {
        if (current_gps.altitude <= (init_gps.altitude+0.1)) {
            switch (optRise) {
                case 0:
                    ROS_INFO("***** Rise to the original height *****");
                    drone_forward(3);
                    drone_stop(1);
                    optRise = 1;
                    break;
                case 1:
                    drone_updown(0.02);
                    break;
            }
        } else if (current_gps.altitude <= (init_gps.altitude-0.6)) {
            drone_updown(0.02);
        } else{
            optRise = 0;
            optSide = 0;
            drone_forward(0.02);
        }
    }
}

void direction_decision::motionCtrl(Box box, float width, float length, float height) {
    if (box.y_max >= -0.5 && box.y_max <= 0.5) {
        switch (optDown) {
            case 0:
                ROS_INFO( "***** turn down *****" );
                drone_stop(0.5);
                optDown = 1;
                optRise = 0;
                break;
            case 1:
                drone_updown(-0.02);
                break;
        }
        return;
    } else {optDown = 0;}
    float cita, C1, C2 ,x;
    int ang;
    if ((box.x_min + box.x_max) / 2 >= 0) {
        //safe mode
//            C1 = box.x_min;
//            C2 = width/2.;
//            x = (2*length*pow(C1,2)
//                       +sqrt(4*pow(length,2)*pow(C1,4)+4*(pow(C1,2)-pow(C2,2))*pow(C1,2)*pow(C2,2)))
//                      /(2*(pow(C1,2)-pow(C2,2)));
            cita = atan((width/2.-box.x_min)/(box.z_min-length/2.)) ;
            ROS_INFO_STREAM("cita = "<<cita*180/C_PI);
            ang = (cita<(30/C_PI)) ? 45 : ((cita<(60/C_PI))? 60 : 90);
            switch (optSide) {
                case 0:
                    ROS_INFO( "***** go ahead forward left *****" );
                    drone_stop(1.0);
                    optSide = 1;
                    break;
                case 1:
                    switch (ang) {
                        case 45:
                            my_drone.pitch_l45(speed);
                            ros::Duration(0.05).sleep();
                            break;
                        case 60:
                            my_drone.pitch_l30(speed);
                            ros::Duration(0.05).sleep();
                            break;
                        case 90:
                            my_drone.roll(speed);
                            ros::Duration(0.05).sleep();
                            break;
                    }
                    break;
            }

    }
    else {
//            C1 = box.x_max;
//            C2 = width/2.;
//            x = (2*length*pow(C1,2)
//                 +sqrt(4*pow(length,2)*pow(C1,4)+4*(pow(C1,2)-pow(C2,2))*pow(C1,2)*pow(C2,2)))
//                /(2*(pow(C1,2)-pow(C2,2)));
            cita = atan((width/2.+box.x_max)/(box.z_min-length/2.)) ;
            ROS_INFO_STREAM("cita = "<<cita*180/C_PI);
            ang = (cita<(30/C_PI)) ? 45 : ((cita<(60/C_PI))? 60 : 90);
        switch (optSide) {
            case 0:
                ROS_INFO( "***** go ahead forward right *****" );
                drone_stop(1.0);
                optSide = 1;
                break;
            case 1:
                switch (ang) {
                    case 45:
                        my_drone.pitch_r45(speed);
                        ros::Duration(0.05).sleep();
                        break;
                    case 60:
                        my_drone.pitch_r30(speed);
                        ros::Duration(0.05).sleep();
                        break;
                    case 90:
                        my_drone.roll(-speed);
                        ros::Duration(0.05).sleep();
                        break;
                }
                break;
        }

    }
}

void direction_decision::drone_forward(float time){
    my_drone.pitch(speed);
    ros::Duration(time).sleep();
}

void direction_decision::drone_stop(float time){
    my_drone.hover();
    ros::Duration(time).sleep();
}

void direction_decision::drone_rotation(float time){
    //plus: turn left; minus: turn right
    my_drone.yaw(time/fabs(time)*speed);
    ros::Duration(fabs(time)).sleep();
}

void direction_decision::drone_updown(float time){
    //plus: turn up; minus: turn down
    my_drone.rise(time/fabs(time)*speed);
    ros::Duration(fabs(time)).sleep();
}

void direction_decision::setTarget(float x, float y, float z){
    target_x=x;
    target_y=y;
    target_z=z;
//    std::cout<<"set target successfully!"<<std::endl;
}

void direction_decision::setDronePos(double x, double y, double z, double yaw){
    drone_x=x;
    drone_y=y;
    drone_z=z;
    drone_yaw=yaw;
//    std::cout<<"set drone position successfully!"<<std::endl;
}

float direction_decision::getAimAngle(){
    //drone_v: drone heading vector
    float drone_v[2] = {cos(drone_yaw), sin(drone_yaw)};
    //drone2tar_v: drone -> target point vector
    float drone2tar_v[2] = {(target_x - drone_x, target_y - drone_y)};
    float target_v[2] = {target_x,target_y};

    float drone_v2[2] = {drone_x+cos(drone_yaw),drone_y+sin(drone_yaw)} ;
    float angle_diff= getAngle(drone_v,drone2tar_v);
    float turn_sign = judgeTurnDirection(drone_v, drone_v2, target_v);

    return turn_sign*angle_diff;

}

float direction_decision::judgeTurnDirection(const float *pos1, const float *pos2, const float *target){
    float c=(pos2[0]-pos1[0])*(target[1]-pos1[1])-(pos2[1]-pos1[1])*(target[0]-pos1[0]);
    if (c>0) return 1.0;
    else return -1.0;
}

float direction_decision::getAngle(const float *v1, const float *v2){
    float x1=v1[0]; float y1=v1[1];
    float x2=v2[0]; float y2=v2[1];
    float v1_length= getLength(v1);
    float v2_length= getLength(v2);
    float cos_angle = (x1 * x2 + y1 * y2) / (v1_length * v2_length);
    return acos(cos_angle);
}

float direction_decision::getLength(const float *v) {
    return (sqrt(pow(v[0],2)+pow(v[1],2)));
}

geometry_msgs::Vector3 direction_decision::toEulerAngle(geometry_msgs::Quaternion quat)
{
    geometry_msgs::Vector3 ans;

    tf::Matrix3x3 R_FLU2ENU(tf::Quaternion(quat.x, quat.y, quat.z, quat.w));
    R_FLU2ENU.getRPY(ans.x, ans.y, ans.z);
    return ans;
}

void direction_decision::attitude_callback(const geometry_msgs::QuaternionStamped::ConstPtr& msg)
{
    current_atti = msg->quaternion;
}

Box BoundingBox(PtCdtr cluster) {

    // Find bounding box for one of the clusters
    PointT minPoint, maxPoint;
    pcl::getMinMax3D(*cluster, minPoint, maxPoint);

    Box box;
    box.x_min = minPoint.x;
    box.y_min = minPoint.y;
    box.z_min = minPoint.z;
    box.x_max = maxPoint.x;
    box.y_max = maxPoint.y;
    box.z_max = maxPoint.z;

    return box;
}

void renderBox(pcl::visualization::PCLVisualizer::Ptr& viewer, Box box, int id){
    std::string cube = "box"+std::to_string(id);
    viewer->addCube(box.x_min, box.x_max, box.y_min, box.y_max, box.z_min, box.z_max, 1, 0, 0, cube);
    viewer->setShapeRenderingProperties(pcl::visualization::PCL_VISUALIZER_REPRESENTATION, pcl::visualization::PCL_VISUALIZER_REPRESENTATION_WIREFRAME, cube);
}
