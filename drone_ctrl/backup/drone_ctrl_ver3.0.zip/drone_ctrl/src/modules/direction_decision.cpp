//
// Created by caleb on 17.05.21.
//

#include "direction_decision.h"

//#define C_EARTH (double)6378137.0
#define C_PI (double)3.141592653589793
//#define DEG2RAD(DEG) ((DEG) * ((C_PI) / (180.0)))
const int color_bar[][3] =
        {
                { 255,0,0},
                { 0,255,0 },
                { 0,0,255 },
                { 0,255,255 },
                { 255,255,0 },
                { 255,255,255 },
                { 255,0,255 }
        };
//TODO: cloudClusters in message rewrite (reference drone_object_ros.cpp)
std::vector<PtCdtr> cloudClusters;
pcl::visualization::PCLVisualizer::Ptr viewer;
//Mission square_mission;

// global variables for subscribed topics



direction_decision::direction_decision(DroneObjectROS &drone,int timeRate_in)
    : nh(), gpsSub(), my_drone(drone)
//    target_x(0.0), target_y(0.0), target_z(0.0),
//    drone_x(0.0), drone_y(0.0), drone_z(0.0), drone_yaw(0.0)
{
    attiSub = nh.subscribe("dji_sdk/attitude", 1, &direction_decision::attitude_callback,this);
    gpsSub = nh.subscribe("dji_sdk/gps_position", 1, &direction_decision::motionStep,this);
//    setTarget(8.4071,49.01381,5);
    timeRate = timeRate_in;
}



direction_decision::~direction_decision(){}

void direction_decision::motionStep(const sensor_msgs::NavSatFix::ConstPtr& msg) {

    int clusterId = 0;

    ///droneBox for collision detection
    Eigen::Vector3f uav_point(-0.8, -0.8, 10);
    float length =  uav_point(2);
    float width = -2 * uav_point(0);
    float height = -2 * uav_point(1);

    Box droneBox = createBox(uav_point, width, length, height);

    ///droneBox_true for angle calculation
    Eigen::Vector3f uav_point_t(-0.75, -0.6, 0.75);
    float length_t = 2 * uav_point_t(2);
    float width_t = -2 * uav_point_t(0);
    float height_t = -2 * uav_point_t(1);
    Box droneBox_t = createBox(uav_point_t, width_t, length_t, height_t);

    UAVBoxVisualization(viewer, droneBox, colors[1], clusterId);


    ////get Angle between drone heading vector and drone2Target vector
    current_gps = *msg;
    if (optGPS == 0) {
        init_gps = *msg;
        optGPS =1;
        ROS_INFO("initial altitude: %.5f", init_gps.altitude);
        setTarget(msg->longitude-0.0003,msg->latitude+0.001,msg->altitude);
    }

    ROS_INFO("GPS: lat=%.5f, long=%.5f, alti=%.5f", msg->latitude, msg->longitude, msg->altitude);
    setDronePos(current_gps.longitude,current_gps.latitude,current_gps.altitude,
                toEulerAngle(current_atti).z);
    //angle2ro: angle for drone to aim to target
    float angle2ro=getAimAngle();
    ROS_INFO("you need rotate %.5f rad, yawRad = %.5f", angle2ro, drone_yaw);
    float dis2tar = sqrt(pow((drone_x-target_x),2)+pow((drone_y-target_y),2));
    ROS_INFO("distance to target is %.5f", dis2tar);
    /// if distance to target is very small, than landing...
    if (dis2tar<0.00001){
        ROS_INFO("***** REACH target point, landing... ******");
        my_drone.land();
        return;
    }
//    if (optGPS == 1) { drone_stop(1);return;}

    /// turn to target
    if (fabs(angle2ro)>C_PI/180 && fabs(angle2ro)<C_PI/6) {
        ROS_INFO("turn to target");
        collision_detection CD_Nav(droneBox);
        CD_Nav.nav_detector(angle2ro);
        if (!CD_Nav.isCollision) {
            drone_stop(0.5);
            drone_rotation(angle2ro / (speed * 5));
            drone_stop(0.5);
            return;
        } else if (fabs(angle2ro) > C_PI / 6) {
            ROS_INFO("after avoidance try to redirecting......");
            collision_detection CD_Nav(droneBox);
            CD_Nav.nav_detector(((angle2ro > 0) ? 1 : -1) * C_PI / 6);
            if (!CD_Nav.isCollision) {
                drone_stop(0.5);
                drone_rotation(((angle2ro > 0) ? 1 : -1) * C_PI / 6 / (speed * 5));
                drone_stop(0.5);
                return;
            }
        }
    }
//
//    if (cloudClusters.empty()){
//        drone_forward(0.05);
//        return;
//    }
    for (const PtCdtr &cluster : cloudClusters) {
        viewer->removeShape("box" + std::to_string(clusterId));
        viewer->removePointCloud("cluster" + std::to_string(clusterId));

        pcl::visualization::PointCloudColorHandlerCustom<PointT> cloud_in_color_h(cluster,
                                                                                  color_bar[clusterId][0],
                                                                                  color_bar[clusterId][1],
                                                                                  color_bar[clusterId][2]);//赋予显示点云的颜色
        viewer->addPointCloud<PointT>(cluster, cloud_in_color_h, "cluster" + std::to_string(clusterId));

        /// 4th: Find bounding boxes for each obstacle cluster
        Box box = BoundingBox(cluster);
        renderBox(viewer, box, clusterId);
        clusterId++;
        /// 5th: Collision Detection && Direction Decision
        /// Rough detection
        collision_detection CD_Rough(box,droneBox);
        CD_Rough.rough_detector();
        if (CD_Rough.isCollision){
            ROS_INFO( "***** There is obstacle in the range *****" );
            viewer->removeShape("uav" + std::to_string(clusterId-1));
            CollisionVisualization(viewer, droneBox, colors[0], clusterId);

//            drone_stop(0.5);
            collision_detection CD(box,droneBox_t);
            CD.rough_detector();
            if (CD.min_distance+length_t/2>d_safe){
                speed=0.02*(CD.min_distance+length_t/2);
                cout<<"speed = "<<speed<<", distance = "<<CD.min_distance+length_t/2<<endl;
                drone_forward(1/timeRate);
                return;
            }

            /// 0/4 direction detector
            std::vector<float> area_lr(2);
            area_lr[0] = (box.x_min-x_min) * (box.y_max-box.y_min); // region 4
            area_lr[1] = (x_max-box.x_max) * (box.y_max-box.y_min); // region 0
            std::vector<float>::iterator biggest = std::max_element(std::begin(area_lr), std::end(area_lr));
            int fs_state = std::distance(std::begin(area_lr), biggest);
            ROS_INFO("lr direction detecting...");
            CD.lr_detector(fs_state);
            ROS_INFO("ang_h = %i, avoidance distance = %.3f" , CD.getFlightAngle_H(),CD.getFlightDistance());

            if (!CD.isCollision){

                mission(CD.direct,CD.getFlightAngle_H(),0,CD.getFlightDistance());
                ROS_INFO_STREAM("the avoidance direction is " << CD.direct);
                speed_counter = 0;
                obs_state = 1;
                return;
            } else {
                /// 1/3/5/7 direction detector
                std::vector<float> area_lrud(4);
                area_lrud[0] = (x_max-box.x_max) * (box.y_min-y_min); // region 1
                area_lrud[1] = (box.x_min-x_min) * (box.y_min-y_min); // region 3
                area_lrud[3] = (box.x_min-x_min) * (y_max-box.y_max); // region 5
                area_lrud[4] = (x_max-box.x_max) * (y_max-box.y_max); // region 7
                biggest = std::max_element(std::begin(area_lrud), std::end(area_lrud));
                fs_state = std::distance(std::begin(area_lrud), biggest);
                ROS_INFO("lrud direction detecting...");
                CD.lrud_detector(fs_state);
                ROS_INFO("ang_h = %i, ang_v = %i, avoidance distance = %.3f" , CD.getFlightAngle_H(),CD.getFlightAngle_V(),CD.getFlightDistance());

                if (!CD.isCollision){

                    mission(CD.direct,CD.getFlightAngle_H(),CD.getFlightAngle_V(),CD.getFlightDistance());
                    ROS_INFO_STREAM("the avoidance direction is " << CD.direct);
                    speed_counter = 0;
                    obs_state = 1;
                    return;
                } else {
                    /// 2/6 direction detector
                    std::vector<float> area_ud(2);
                    area_ud[0] = (box.x_max-box.x_min) * (box.y_min-y_min); // region 2
                    area_ud[1] = (box.x_max-box.x_min) * (y_max-box.y_max); // region 6
                    biggest = std::max_element(std::begin(area_ud), std::end(area_ud));
                    fs_state = std::distance(std::begin(area_ud), biggest);
                    ROS_INFO("ud direction detecting...");
                    CD.ud_detector(fs_state);
                    ROS_INFO("ang_v = %i, avoidance distance = %.3f" , CD.getFlightAngle_V(),CD.getFlightDistance());

                    if (!CD.isCollision){

                        mission(CD.direct,0,CD.getFlightAngle_V(),CD.getFlightDistance());
                        ROS_INFO_STREAM("the avoidance direction is " << CD.direct);
                        speed_counter = 0;
                        obs_state = 1;
                        return;
                    } else {
                        fs_state = std::distance(std::begin(area_lr), biggest);
                        ROS_INFO_STREAM("emergency situation!!! go to side, waiting for new path");
                        //CD.emergency_detector(fs_state);
                        drone_stop(0.5);
                        (fs_state==0)? drone_rotation(C_PI/6 / (speed * 5)):drone_rotation(-C_PI/6 / (speed * 5));
                        //mission(CD.direct,CD.getFlightAngle_H(),0,CD.getFlightDistance());
                        speed_counter = 0;
                        obs_state = 1;
                        return;
                    }
                }
            }

        }

    }
    ROS_INFO("======= SAFE FLYING =======");
    if (speed_counter != timeRate*2 && obs_state == 1) {
        if (speed_counter == 0)speed=0.1;
        speed = speed + 0.2/(2*timeRate);
        drone_forward(1/timeRate);
        speed_counter++;
    } else {
        obs_state = 0;
        speed = 0.3;
        drone_forward(1/timeRate);
    }


}
void direction_decision::mission(int direct, int angleH, int angleV, float distance){
    switch (direct) {
        case 0: {
            if (angleH == 30) {
                my_drone.move(0.606 * speed, -speed, 0, 0);
                //ros::Duration(distance * sin(fabs(angleH)) / (speed * 15)).sleep();
            } else {
                my_drone.move(0.202 * speed, -speed, 0, 0);
                //ros::Duration(distance * sin(fabs(angleH)) / (speed * 15)).sleep();
            }
            break;
        }
        case 1: {
            float cos_angle = (cos(angleH * C_PI / 180) + cos(angleV * C_PI / 180)) /
                              (2 + 2 * cos(angleH * C_PI / 180) * cos(angleV * C_PI / 180));
            float angle = acos(cos_angle);
            if (angleH == 30) {
                if (angleV == 30) {
                    my_drone.move(0.606 * speed, -speed, speed, 0);
                    //ros::Duration(distance * sin(angle) / (speed * 15)).sleep();
                } else {
                    my_drone.move(0.606 * speed, -speed, 3*speed, 0);
                    //ros::Duration(distance * sin(angle) / (speed * 15)).sleep();
                }
            } else {
                if (angleV == 60) {
                    my_drone.move(0.202 * speed, -speed, speed, 0);
                    //ros::Duration(distance * sin(angle) / (speed * 15)).sleep();
                } else {
                    my_drone.move(0.202 * speed, -speed, 0.333*speed, 0);
                    //ros::Duration(distance * sin(angle) / (speed * 15)).sleep();
                }

            }
            break;
        }
        case 2: {
            if (angleV == 30) {
                my_drone.move(0.606 * speed, 0, speed, 0);
                //ros::Duration(distance * sin(fabs(angleV)) / (speed * 15)).sleep();
            } else {
                my_drone.move(0.202 * speed, 0, speed, 0);
                //ros::Duration(distance * sin(fabs(angleV)) / (speed * 15)).sleep();
            }
            break;
        }
        case 3: {
            float cos_angle = (cos(angleH * C_PI / 180) + cos(angleV * C_PI / 180)) /
                              (2 + 2 * cos(angleH * C_PI / 180) * cos(angleV * C_PI / 180));
            float angle = acos(cos_angle);
            if (angleH == 30) {
                if (angleV == 30) {
                    my_drone.move(0.606 * speed, speed, speed, 0);
                    //ros::Duration(distance * sin(angle) / (speed * 15)).sleep();
                } else {
                    my_drone.move(0.606 * speed, speed, 3*speed, 0);
                    //ros::Duration(distance * sin(angle) / (speed * 15)).sleep();
                }
            } else {
                if (angleV == 60) {
                    my_drone.move(0.202 * speed, speed, speed, 0);
                    //ros::Duration(distance * sin(angle) / (speed * 15)).sleep();
                } else {
                    my_drone.move(0.202 * speed, speed, 0.333*speed, 0);
                    //ros::Duration(distance * sin(angle) / (speed * 15)).sleep();
                }
            }
            break;
        }

        case 4: {
            if (angleH == -30) {
                my_drone.move(0.606 * speed, speed, 0, 0);
                //ros::Duration(distance * sin(fabs(angleH)) / (speed * 15)).sleep();
            } else {
                my_drone.move(0.202 * speed, speed, 0, 0);
                //ros::Duration(distance * sin(fabs(angleH)) / (speed * 15)).sleep();
            }
            break;
        }
        case 5: {
            float cos_angle = (cos(angleH * C_PI / 180) + cos(angleV * C_PI / 180)) /
                              (2 + 2 * cos(angleH * C_PI / 180) * cos(angleV * C_PI / 180));
            float angle = acos(cos_angle);
            if (angleH == 30) {
                if (angleV == 30) {
                    my_drone.move(0.606 * speed, speed, -speed, 0);
                    //ros::Duration(distance * sin(angle) / (speed * 15)).sleep();
                } else {
                    my_drone.move(0.606 * speed, speed, -3*speed, 0);
                    //ros::Duration(distance * sin(angle) / (speed * 15)).sleep();
                }
            } else {
                if (angleV == 60) {
                    my_drone.move(0.202 * speed, speed, -speed, 0);
                    //ros::Duration(distance * sin(angle) / (speed * 15)).sleep();
                } else {
                    my_drone.move(0.202 * speed, speed, -0.333*speed, 0);
                    //ros::Duration(distance * sin(angle) / (speed * 15)).sleep();
                }
            }
            break;
        }
        case 6: {
            if (angleV == 30) {
                my_drone.move(0.606 * speed, 0, -speed, 0);
                //ros::Duration(distance * sin(fabs(angleV)) / (speed * 15)).sleep();
            } else {
                my_drone.move(0.202 * speed, 0, -speed, 0);
                //ros::Duration(distance * sin(fabs(angleV)) / (speed * 15)).sleep();
            }
            break;
        }
        case 7: {
            float cos_angle = (cos(angleH * C_PI / 180) + cos(angleV * C_PI / 180)) /
                              (2 + 2 * cos(angleH * C_PI / 180) * cos(angleV * C_PI / 180));
            float angle = acos(cos_angle);
            if (angleH == 30) {
                if (angleV == 30) {
                    my_drone.move(0.606 * speed, -speed, -speed, 0);
                    //ros::Duration(distance * sin(angle) / (speed * 15)).sleep();
                } else {
                    my_drone.move(0.606 * speed, -speed, -3*speed, 0);
                    //ros::Duration(distance * sin(angle) / (speed * 15)).sleep();
                }
            } else {
                if (angleV == 60) {
                    my_drone.move(0.202 * speed, -speed, -speed, 0);
                    //ros::Duration(distance * sin(angle) / (speed * 15)).sleep();
                } else {
                    my_drone.move(0.202 * speed, -speed, -0.333*speed, 0);
                    //ros::Duration(distance * sin(angle) / (speed * 15)).sleep();
                }

            }
            break;
        }
        case 8:{
            if (angleH == -90){
                my_drone.move(0,speed,0,0);
                //ros::Duration(distance / (speed * 15)).sleep();
            } else {
                my_drone.move(0,-speed,0,0);
                //ros::Duration(distance / (speed * 15)).sleep();
            }
            break;
        }
    }
}
void direction_decision::motionCtrl(Box box, float width, float length, float height) {
    if (box.y_max >= -0.5 && box.y_max <= 0.5) {
        switch (optDown) {
            case 0:
                ROS_INFO( "***** turn down *****" );
                drone_stop(0.5);
                optDown = 1;
                optRise = 0;
                break;
            case 1:
                drone_updown(-0.02);
                break;
        }
        return;
    } else {optDown = 0;}
    float cita, C1, C2 ,x;
    int ang;
    if ((box.x_min + box.x_max) / 2 >= 0) {
        //safe mode
//            C1 = box.x_min;
//            C2 = width/2.;
//            x = (2*length*pow(C1,2)
//                       +sqrt(4*pow(length,2)*pow(C1,4)+4*(pow(C1,2)-pow(C2,2))*pow(C1,2)*pow(C2,2)))
//                      /(2*(pow(C1,2)-pow(C2,2)));
            cita = atan((width/2.-box.x_min)/(box.z_min-length/2.)) ;
            ROS_INFO_STREAM("cita = "<<cita*180/C_PI);
            ang = (cita<(30/C_PI)) ? 45 : ((cita<(60/C_PI))? 60 : 90);
            switch (optSide) {
                case 0:
                    ROS_INFO( "***** go ahead forward left *****" );
                    drone_stop(1.0);
                    optSide = 1;
                    break;
                case 1:
                    switch (ang) {
                        case 45:
                            my_drone.pitch_l45(speed);
                            ros::Duration(0.05).sleep();
                            break;
                        case 60:
                            my_drone.pitch_l30(speed);
                            ros::Duration(0.05).sleep();
                            break;
                        case 90:
                            my_drone.roll(speed);
                            ros::Duration(0.05).sleep();
                            break;
                    }
                    break;
            }

    }
    else {
//            C1 = box.x_max;
//            C2 = width/2.;
//            x = (2*length*pow(C1,2)
//                 +sqrt(4*pow(length,2)*pow(C1,4)+4*(pow(C1,2)-pow(C2,2))*pow(C1,2)*pow(C2,2)))
//                /(2*(pow(C1,2)-pow(C2,2)));
            cita = atan((width/2.+box.x_max)/(box.z_min-length/2.)) ;
            ROS_INFO_STREAM("cita = "<<cita*180/C_PI);
            ang = (cita<(30/C_PI)) ? 45 : ((cita<(60/C_PI))? 60 : 90);
        switch (optSide) {
            case 0:
                ROS_INFO( "***** go ahead forward right *****" );
                drone_stop(1.0);
                optSide = 1;
                break;
            case 1:
                switch (ang) {
                    case 45:
                        my_drone.pitch_r45(speed);
                        ros::Duration(0.05).sleep();
                        break;
                    case 60:
                        my_drone.pitch_r30(speed);
                        ros::Duration(0.05).sleep();
                        break;
                    case 90:
                        my_drone.roll(-speed);
                        ros::Duration(0.05).sleep();
                        break;
                }
                break;
        }

    }
}

void direction_decision::drone_forward(float time){
    my_drone.pitch(0.5*speed);
    ros::Duration(time).sleep();
}

void direction_decision::drone_stop(float time){
    my_drone.hover();
    ros::Duration(time).sleep();
}

void direction_decision::drone_rotation(float time){
    //plus: turn left; minus: turn right
    my_drone.yaw(time/fabs(time)*speed);
    ros::Duration(fabs(time)).sleep();
}

void direction_decision::drone_updown(float time){
    //plus: turn up; minus: turn down
    my_drone.rise(time/fabs(time)*speed);
    ros::Duration(fabs(time)).sleep();
}

void direction_decision::setTarget(float x, float y, float z){
    target_x=x;
    target_y=y;
    target_z=z;
//    std::cout<<"set target successfully!"<<std::endl;
}

void direction_decision::setDronePos(double x, double y, double z, double yaw){
    drone_x=x;
    drone_y=y;
    drone_z=z;
    drone_yaw=yaw;
//    std::cout<<"set drone position successfully!"<<std::endl;
}

float direction_decision::getAimAngle(){

    float yaw_ture = C_PI /2 + drone_yaw;
    //drone_v: drone heading vector
    float drone_v[2] = {cos(yaw_ture), sin(yaw_ture)};
    //drone2tar_v: drone -> target point vector
    float drone2tar_v[2] = {target_x - drone_x, target_y - drone_y};
    float target_v[2] = {target_x,target_y};
    float drone_v2[2] = {drone_x+cos(yaw_ture),drone_y+sin(yaw_ture)} ;
    float angle_diff= getAngle(drone_v,drone2tar_v);
    float turn_sign = judgeTurnDirection(drone_v, drone2tar_v);

    return turn_sign*angle_diff;

}

float direction_decision::judgeTurnDirection(const float *pos1, const float *pos2){
    float c=pos1[0]*pos2[1]-pos1[1]*pos2[0];
    if (c>0) return 1.0; // turn left
    else return -1.0; // turn right
}

float direction_decision::getAngle(const float *v1, const float *v2){
    float x1=v1[0]; float y1=v1[1];
    float x2=v2[0]; float y2=v2[1];
    float v1_length= getLength(v1);
    float v2_length= getLength(v2);
    float cos_angle = (x1 * x2 + y1 * y2) / (v1_length * v2_length);
    return acos(cos_angle);
}

float direction_decision::getLength(const float *v) {
    return (sqrt(pow(v[0],2)+pow(v[1],2)));
}

geometry_msgs::Vector3 direction_decision::toEulerAngle(geometry_msgs::Quaternion quat)
{
    geometry_msgs::Vector3 ans;

    tf::Matrix3x3 R_FLU2ENU(tf::Quaternion(quat.x, quat.y, quat.z, quat.w));
    R_FLU2ENU.getRPY(ans.x, ans.y, ans.z);
    return ans;
}

void direction_decision::attitude_callback(const geometry_msgs::QuaternionStamped::ConstPtr& msg)
{
    current_atti = msg->quaternion;
}

Box BoundingBox(PtCdtr cluster) {

    // Find bounding box for one of the clusters
    PointT minPoint, maxPoint;
    pcl::getMinMax3D(*cluster, minPoint, maxPoint);

    Box box;
    box.x_min = minPoint.x;
    box.y_min = minPoint.y;
    box.z_min = minPoint.z;
    box.x_max = maxPoint.x;
    box.y_max = maxPoint.y;
    box.z_max = maxPoint.z;

    return box;
}

void renderBox(pcl::visualization::PCLVisualizer::Ptr& viewer, Box box, int id){
    std::string cube = "box"+std::to_string(id);
    viewer->addCube(box.x_min, box.x_max, box.y_min, box.y_max, box.z_min, box.z_max, 1, 0, 0, cube);
    viewer->setShapeRenderingProperties(pcl::visualization::PCL_VISUALIZER_REPRESENTATION, pcl::visualization::PCL_VISUALIZER_REPRESENTATION_WIREFRAME, cube);
}
