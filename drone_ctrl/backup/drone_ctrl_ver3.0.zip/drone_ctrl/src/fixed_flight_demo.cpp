#include "ros/ros.h"
#include "../include/drone_object_ros.h"
#include <sstream>

//模拟环境转指定角度：v=speed, t=phi*pi/180/(speed*5)
//模拟环境飞行指定距离：v=speed, t=distance*(1/(speed*15)) (可能）
//v=speed, t=distance/(speed*5)) (未验证）
const float speed = 0.2;
const float pi = 3.14159265;
void fixed_flight_demo(DroneObjectROS &drone) {
    drone.monitoredTakeoff();
    drone.takeOff();

//    drone.hover();
//    ros::Duration(0.5).sleep();
//    drone.yaw(speed);
//    ros::Duration(6.28).sleep();// 1 round
    drone.hover();
    ros::Duration(2.0).sleep();
//    drone.pitch_l45(speed);
//    ros::Duration(3).sleep();
//    drone.hover();
//    ros::Duration(3).sleep();
//    drone.pitch_r45(speed);
//    ros::Duration(3).sleep();
//    drone.hover();
//    ros::Duration(3).sleep();
//    drone.pitch_l30(speed);
//    ros::Duration(3).sleep();
//    drone.hover();
//    ros::Duration(3).sleep();
//    drone.pitch(speed);
//    ros::Duration(3*(1/(speed*17))).sleep();
    drone.rise(speed);
    ros::Duration(3*(1/(0.29*speed*17))).sleep();

//    drone.yaw(speed);
//    ros::Duration(45*pi/180/(speed*5)).sleep();
//    drone.yaw(-speed);
//    ros::Duration(90*pi/180/(speed*5)).sleep();
//    drone.yaw(speed);
//    ros::Duration(45*pi/180/(speed*5)).sleep();
//    drone.pitch(speed);
//    ros::Duration(5*0.333).sleep();
//    drone.move(0.375*speed,speed,speed,0);
//    ros::Duration(5).sleep();
//    drone.move(0.202*speed, speed, speed,0);
//    ros::Duration(3).sleep();
    drone.hover();
    ros::Duration(3).sleep();
    drone.land();
}


int main(int argc, char **argv) {
    ros::init(argc, argv, "fixed_flight_demo");
    ros::NodeHandle node;
    DroneObjectROS drone(node);
    ros::Duration(1.0).sleep(); // wait for receiving rosnode

    fixed_flight_demo(drone);

    ros::Rate loop_rate(1); // rate in Hz
    while (ros::ok()) {

        ROS_INFO_STREAM("do something regularly");
        ros::spinOnce();
        loop_rate.sleep();
    }
    return 0;
}
