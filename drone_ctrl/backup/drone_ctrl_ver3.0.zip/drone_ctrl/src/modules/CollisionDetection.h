//
// Created by caleb on 10.05.21.
//

#ifndef PCFILTER_COLLISIONDETECTION_H
#define PCFILTER_COLLISIONDETECTION_H

// Collision, Distance
#include <fcl/narrowphase/collision_object.h>
#include <fcl/narrowphase/distance.h>
#include <fcl/broadphase/broadphase_dynamic_AABB_tree.h>
#include "fcl/broadphase/default_broadphase_callbacks.h"
// Distance Request & Result
//#include <fcl/narrowphase/distance_request.h>
//#include <fcl/narrowphase/distance_result.h>

#include "pointcloud_processing.h"
#include <Eigen/Dense>
struct Color
{

    float r, g, b;

    Color(float setR, float setG, float setB)
            : r(setR), g(setG), b(setB)
    {}
};


    Box createBox(Eigen::Vector3f uav_point, float width, float length, float height);

    bool isCollision(Box box, Box uav);

    void CollisionVisualization(pcl::visualization::PCLVisualizer::Ptr& viewer, Box box, Color color,int id);

    void UAVBoxVisualization(pcl::visualization::PCLVisualizer::Ptr& viewer, Box box, Color color,int id);


class collision_detection{
public:
    collision_detection(const PtCdtr &cluster, float width, float length, float height);

    collision_detection(Box obj,Box drone);
    collision_detection(Box drone);
    ~collision_detection();

    void rough_detector();
    void lr_detector(int fs_state);
    void lrud_detector(int fs_state);
    void ud_detector(int fs_state);
    void emergency_detector(int fs_state);
    void nav_detector(float angle_in);

    int getFlightAngle_H();
    int getFlightAngle_V();
    float getFlightDistance();

    float min_distance;
    bool isCollision;
    int direct;

private:

    Eigen::Matrix3f setRPY(Eigen::Vector3f rot);

    fcl::CollisionObjectf createCollisionObject(pcl::PointCloud<pcl::PointXYZ>::Ptr pointcloud_ptr);

    Box BoundingBox(PtCdtr cluster);

    // Distance Request and Result
    fcl::DistanceRequestf request;
    fcl::DistanceResultf result;
    fcl::CollisionRequestf C_request;
    fcl::CollisionResultf C_result;
    fcl::DefaultDistanceData<float> d_data1;
    fcl::DefaultCollisionData<float> c_data1;

    float cita_h,cita_v;
    int ang_h,ang_v; // flight angel: vertical, horizontal
    Box obj,drone;
    float drone_w, drone_h, drone_l;
    float detec_l;
//    PtCdtr cluster;
//    float width; float length; float height;
};
#endif //PCFILTER_COLLISIONDETECTION_H
