#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QDialog>
#include "abstract_module.h"

namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = 0);
    ~MainWindow();
    float longitude;
    float latitude;
    int click_state = 0;
private slots:
    void on_pushButton_clicked();

private:
    Ui::MainWindow *ui;
    float current_lo;
    float current_la;
};

#endif // MAINWINDOW_H
