//
// Created by caleb on 12.05.21.
//

#include "ros/ros.h"
#include "../include/drone_object_ros.h"
#include "modules/pointcloud_processing.h"
#include "modules/direction_decision.h"


int main(int argc, char **argv) {


    ros::init(argc, argv, "drone_Pathfinder");
    ros::NodeHandle flight_cmd_nh;

    DroneObjectROS drone(flight_cmd_nh);
    ros::Duration(0.1).sleep(); // wait for dji rosNode
    drone.monitoredTakeoff();
    drone.takeOff();

    // start modules
    boost::shared_ptr<pcl::visualization::PCLVisualizer> pc_viewer(new pcl::visualization::PCLVisualizer("PointCloud view"));
    pc_viewer->setCameraPosition(-40, -30, -20, 0, 0, 15,1,-7,-1);

    pointcloud_processing pc_proc(drone,pc_viewer);

    direction_decision dir_dec(drone);

    ros::Rate loop_rate(50);

    while(!pc_viewer->wasStopped()) {
        pc_viewer->removeAllPointClouds();
        pc_viewer->removeAllShapes();
        ros::spinOnce();
        loop_rate.sleep();
        pc_viewer->spinOnce();
    }

    return 0;
}