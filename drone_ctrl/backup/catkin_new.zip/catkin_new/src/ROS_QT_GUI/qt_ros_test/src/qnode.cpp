﻿//
// Created by caleb on 15.07.21.
//

#include "qnode.h"

QNode::QNode(int argc, char** argv )
    : init_argc(argc), init_argv(argv)
{}

QNode::~QNode()
{
    if(ros::isStarted())
    {
        ros::shutdown();
        ros::waitForShutdown();
    }
    wait();
}

bool QNode::init()
{

  start();
  return true;
}

void QNode::gpsCallback(const std_msgs::Float32MultiArray::ConstPtr& msg)
{
//    current_gps = *msg;
//    target_gps = *msg;
      ROS_INFO_STREAM("i heard "<<msg->data.at(0)<<" "<<msg->data.at(1));
}
void QNode::gpsCallback_2(const sensor_msgs::NavSatFix::ConstPtr& msg)
{
   ROS_INFO("GPS: lat=%.5f, long=%.5f, alti=%.5f", msg->latitude, msg->longitude, msg->altitude);
}
void QNode::run()
{
  ros::init(init_argc,init_argv, "gps_listener");
  ros::start(); // explicitly needed since our nodehandle is going out of scope.
  ros::NodeHandle n;
  // Add your ros communications here.
//  chatter_publisher = n.advertise<std_msgs::Float32MultiArray>("target_point_gps", 1000);
//  chatter_subscriber = n.subscribe("dji_sdk/gps_position", 1, &QNode::gpsCallback,this);
  chatter_subscriber = n.subscribe("target_point_gps", 1000, &QNode::gpsCallback,this);
  chatter_subscriber_2 = n.subscribe("dji_sdk/gps_position", 1, &QNode::gpsCallback_2,this);
  //ros::spin();
  boost::shared_ptr<pcl::visualization::PCLVisualizer> pc_viewer(new pcl::visualization::PCLVisualizer("PointCloud view"));
//  std::cout<<"successful subscribe"<<std::endl;
  ros::Rate loop_rate(10);
//  ros::Duration initDur(0.1);
  int count = 0;
  while (ros::ok()&&!pc_viewer->wasStopped())
  {
//      std_msgs::String msg;
//      std::stringstream ss;
//      ss << "hello world -- " << count;
//      msg.data = ss.str();
//      chatter_publisher.publish(msg);
//    ROS_INFO("i heard %.5f %.5f, %i",target_gps.data.at(0),target_gps.data.at(1),count);
//        std::cout<<count<<std::endl;
      ros::spinOnce();
      loop_rate.sleep();
      pc_viewer->spinOnce();
      //initDur.sleep();
      ++count;
  }
  std::cout << "Ros shutdown, proceeding to close the gui." << std::endl;

}
