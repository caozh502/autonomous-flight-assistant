#include "ros/ros.h"
#include "../include/drone_object_ros.h"
#include <sstream>

const float speed = 0.2;

void fixed_flight_demo(DroneObjectROS &drone) {
    drone.monitoredTakeoff();
    drone.takeOff();

//    drone.hover();
//    ros::Duration(0.5).sleep();
//    drone.yaw(speed);
//    ros::Duration(6.28).sleep();// 1 round
//    drone.hover();
//    ros::Duration(1.0).sleep();
    drone.pitch_l45(speed);
    ros::Duration(3).sleep();
    drone.hover();
    ros::Duration(3).sleep();
    drone.pitch_r45(speed);
    ros::Duration(3).sleep();
    drone.hover();
    ros::Duration(3).sleep();
    drone.pitch_l30(speed);
    ros::Duration(3).sleep();
    drone.hover();
    ros::Duration(3).sleep();
    drone.pitch_r30(speed);
    ros::Duration(3).sleep();
    drone.hover();
    ros::Duration(3).sleep();
    drone.land();
}


int main(int argc, char **argv) {
    ros::init(argc, argv, "fixed_flight_demo");
    ros::NodeHandle node;
    DroneObjectROS drone(node);
    ros::Duration(1.0).sleep(); // wait for receiving rosnode

    fixed_flight_demo(drone);

    ros::Rate loop_rate(1); // rate in Hz
    while (ros::ok()) {

        ROS_INFO_STREAM("do something regularly");
        ros::spinOnce();
        loop_rate.sleep();
    }
    return 0;
}
