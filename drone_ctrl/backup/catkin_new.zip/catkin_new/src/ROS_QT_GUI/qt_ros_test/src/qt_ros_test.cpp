#include "qt_ros_test.h"
#include "qt_ros_test/ui_qt_ros_test.h"
#include <QString>
#include <QtGui>
#include <QMessageBox>
#include <std_msgs/String.h>
#include "std_msgs/Float32MultiArray.h"

Qt_Ros_Test::Qt_Ros_Test(int argc, char** argv,QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Qt_Ros_Test),
    qnode(argc,argv)
{
    ui->setupUi(this);

//   ui->lineEdit->setText(QString::number(ui->verticalSlider->value()));
    QObject::connect(ui->actionAbout_Qt, SIGNAL(triggered(bool)), qApp, SLOT(aboutQt())); // qApp is a global variable for the application
//    QObject::connect(ui->verticalSlider, SIGNAL(valueChanged(int)),
//                     this, SLOT(on_slider_value_change(int)));
    ui->lineEdit->setText("0.01");
    ui->lineEdit_2->setText("0.01");
//    QObject::connect(&qnode, SIGNAL(rosShutdown()), this, SLOT(close()));
    ros::init(argc, argv, "gps_info");
    if (!ros::master::check())
    {
        ROS_INFO("No master started!");
        this->close();
    }
    ros::start(); // explicitly needed since our nodehandle is going out of scope.
    ros::NodeHandle n;
    chatter_publisher = n.advertise<std_msgs::Float32MultiArray>("target_point_gps", 1000);
    if( ui->checkBox->isChecked() )
    {
        on_pushButton_clicked(true);
    }


    //ros::spin();
}

Qt_Ros_Test::~Qt_Ros_Test()
{
    delete ui;
}

//void Qt_Ros_Test::on_slider_value_change(int value)
//{
//    ui->lineEdit->setText(QString::number(value));

//    std_msgs::String msg;
//    std::stringstream ss;
//    ss << "data: " << ui->verticalSlider->value();
//    msg.data = ss.str();
//    chatter_publisher.publish(msg);

//}


void Qt_Ros_Test::on_pushButton_clicked(bool checked)
{
  if (qnode.init()){
    QString longitude_ = ui->lineEdit->text();
    QString latitude_ = ui->lineEdit_2->text();
    longitude = longitude_.toFloat();
    latitude = latitude_.toFloat();

    std_msgs::Float32MultiArray msg;
    msg.data.push_back(longitude);
    msg.data.push_back(latitude);
    chatter_publisher.publish(msg);
    std::cout<<"successful push"<<std::endl;
    click_state=1;

  }
}
