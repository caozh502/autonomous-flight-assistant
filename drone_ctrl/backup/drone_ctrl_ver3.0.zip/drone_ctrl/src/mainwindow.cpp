#include "modules/mainwindow.h"
#include <QtWidgets>
#include "ui_mainwindow.h"

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    ui->label_7->setNum(current_lo);
    ui->label_8->setNum(current_la);
}

MainWindow::~MainWindow()
{
    delete ui;
}



void MainWindow::on_pushButton_clicked()
{
    QString longitude_ = ui->lineEdit->text();
    QString latitude_ = ui->lineEdit_2->text();
    longitude = longitude_.toFloat();
    latitude = latitude_.toFloat();
    click_state = 1;
}
