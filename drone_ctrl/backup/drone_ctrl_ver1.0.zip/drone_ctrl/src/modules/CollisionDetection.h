//
// Created by caleb on 10.05.21.
//

#ifndef PCFILTER_COLLISIONDETECTION_H
#define PCFILTER_COLLISIONDETECTION_H

// Collision, Distance
#include <fcl/narrowphase/collision_object.h>
#include <fcl/narrowphase/distance.h>
#include <fcl/broadphase/broadphase_dynamic_AABB_tree.h>
#include "fcl/broadphase/default_broadphase_callbacks.h"
// Distance Request & Result
#include <fcl/narrowphase/distance_request.h>
#include <fcl/narrowphase/distance_result.h>

#include "pointcloud_processing.h"
#include <vector>
#include <Eigen/Dense>
#include <pcl/visualization/pcl_visualizer.h>
struct Color
{

    float r, g, b;

    Color(float setR, float setG, float setB)
            : r(setR), g(setG), b(setB)
    {}
};


        Box createBox(Eigen::Vector3f uav_point, float width, float length, float height);


        bool isCollision(Box box, Box uav);

        void CollisionVisualization(pcl::visualization::PCLVisualizer::Ptr& viewer, Box box, Color color,int id);

        void UAVBoxVisualization(pcl::visualization::PCLVisualizer::Ptr& viewer, Box box, Color color,int id);

        Eigen::Matrix3f setRPY(const Eigen::Vector3f rot);

        fcl::CollisionObjectf createCollisionObject(const pcl::PointCloud<pcl::PointXYZ>::Ptr pointcloud_ptr);
#endif //PCFILTER_COLLISIONDETECTION_H
