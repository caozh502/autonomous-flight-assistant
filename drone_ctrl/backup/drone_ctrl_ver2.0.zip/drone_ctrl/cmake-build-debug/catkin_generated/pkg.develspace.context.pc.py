# generated from catkin/cmake/template/pkg.context.pc.in
CATKIN_PACKAGE_PREFIX = ""
PROJECT_PKG_CONFIG_INCLUDE_DIRS = "/home/caleb/catkin_ws/src/prognodrone/drone_ctrl/include".split(';') if "/home/caleb/catkin_ws/src/prognodrone/drone_ctrl/include" != "" else []
PROJECT_CATKIN_DEPENDS = "roscpp;rospy;image_transport;std_msgs;sensor_msgs;geometry_msgs;message_runtime;cv_bridge".replace(';', ' ')
PKG_CONFIG_LIBRARIES_WITH_PREFIX = "".split(';') if "" != "" else []
PROJECT_NAME = "drone_ctrl"
PROJECT_SPACE_DIR = "/home/caleb/catkin_ws/src/prognodrone/drone_ctrl/cmake-build-debug/devel"
PROJECT_VERSION = "0.0.0"
