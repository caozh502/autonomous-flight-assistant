//
// Created by caleb on 12.05.21.
//

#ifndef SRC_POINTCLOUD_PROCESSING_H
#define SRC_POINTCLOUD_PROCESSING_H

#include <iostream>
#include <vector>
#include <pcl/common/common.h>
#include <pcl/point_types.h>
#include <pcl/point_cloud.h>

#include <pcl/filters/voxel_grid.h>
#include <pcl/visualization/pcl_visualizer.h>

#include <pcl/filters/extract_indices.h>
#include <pcl/ModelCoefficients.h>
#include <pcl/segmentation/sac_segmentation.h>
#include <pcl/filters/passthrough.h>
#include <pcl/filters/conditional_removal.h>
#include <pcl/features/normal_3d.h>
#include <pcl/kdtree/kdtree.h>
#include <pcl/sample_consensus/method_types.h>
#include <pcl/sample_consensus/model_types.h>
#include <pcl/segmentation/extract_clusters.h>


#include <pcl_conversions/pcl_conversions.h>
#include <pcl/conversions.h>
#include <sensor_msgs/PointCloud2.h>
#include <sensor_msgs/NavSatFix.h>

#include "abstract_module.h"


typedef pcl::PointXYZRGB PointT;
typedef pcl::PointCloud<PointT>::Ptr PtCdtr;

extern std::vector<PtCdtr> cloudClusters;
extern pcl::visualization::PCLVisualizer::Ptr viewer;
extern PtCdtr cp_filtered;


struct Box
{
    float x_min;
    float y_min;
    float z_min;
    float x_max;
    float y_max;
    float z_max;
};

class pointcloud_processing : public abstract_module{
    ros::NodeHandle nh;
    ros::Publisher pub;
    ros::Subscriber point_sub;
    ros::Subscriber gps_sub;
public:
    pointcloud_processing(boost::shared_ptr<pcl::visualization::PCLVisualizer>& pc_viewer);

    ~pointcloud_processing();

private:
    void processStep(const sensor_msgs::PointCloud2ConstPtr& cloud_msg);

    PtCdtr FilterCloud(PtCdtr cloud, float filterRes);

    std::pair<PtCdtr, PtCdtr>
    RansacSegmentPlane(PtCdtr cloud, int maxIterations, float distanceTol);

    std::vector<PtCdtr>EuclidCluster(PtCdtr cloud, float clusterTolerance, int minSize,int maxSize);

    void gpsCallback(const sensor_msgs::NavSatFix::ConstPtr& msg);

    void renderPointCloud(pcl::visualization::PCLVisualizer::Ptr& viewer, const PtCdtr& cloud,std::string name);
    //Parameters
    int gps_state = 0;
    sensor_msgs::NavSatFix init_gps;
    sensor_msgs::NavSatFix current_gps;

};






#endif //SRC_POINTCLOUD_PROCESSING_H
