#include <std_msgs/String.h>
#include "std_msgs/Float32MultiArray.h"
#include <sensor_msgs/NavSatFix.h>
#include <ros/ros.h>
#include <QThread>
#include <pcl/visualization/pcl_visualizer.h>

class QNode : public QThread
{
    Q_OBJECT
public:
    QNode(int argc, char** argv);
    virtual ~QNode();
    void run();
    bool init();
    void gpsCallback(const std_msgs::Float32MultiArray::ConstPtr& msg);
    void gpsCallback_2(const sensor_msgs::NavSatFix::ConstPtr& msg);
private:
    ros::Publisher chatter_publisher;
    ros::Subscriber chatter_subscriber;
    ros::Subscriber chatter_subscriber_2;
    sensor_msgs::NavSatFix current_gps;
    std_msgs::Float32MultiArray target_gps;
    int init_argc;
    char** init_argv;
};
