//
// Created by caleb on 12.05.21.
//

#ifndef SRC_POINTCLOUD_PROCESSING_H
#define SRC_POINTCLOUD_PROCESSING_H

#include <iostream>
#include <vector>
#include <pcl/common/common.h>
#include <pcl/point_types.h>
#include <pcl/point_cloud.h>
#include <pcl/io/pcd_io.h>
#include <pcl/filters/voxel_grid.h>
#include <pcl/visualization/pcl_visualizer.h>
#include <pcl/visualization/cloud_viewer.h>
#include <pcl/filters/extract_indices.h>
#include <pcl/ModelCoefficients.h>
#include <pcl/segmentation/sac_segmentation.h>
#include <pcl/filters/passthrough.h>
#include <pcl/features/normal_3d.h>
#include <pcl/kdtree/kdtree.h>
#include <pcl/sample_consensus/method_types.h>
#include <pcl/sample_consensus/model_types.h>
#include <pcl/segmentation/extract_clusters.h>


#include <pcl_conversions/pcl_conversions.h>
#include <pcl/conversions.h>
#include <sensor_msgs/PointCloud2.h>

#include "abstract_module.h"


typedef pcl::PointXYZRGB PointT;
typedef pcl::PointCloud<PointT>::Ptr PtCdtr;

extern std::vector<PtCdtr> cloudClusters;
extern pcl::visualization::PCLVisualizer::Ptr viewer;


struct Box
{
    float x_min;
    float y_min;
    float z_min;
    float x_max;
    float y_max;
    float z_max;
};

class pointcloud_processing : public abstract_module{
    ros::NodeHandle nh;
    ros::Publisher pub;
    ros::Subscriber point_sub;
    DroneObjectROS my_drone;

public:
    pointcloud_processing(DroneObjectROS &drone,boost::shared_ptr<pcl::visualization::PCLVisualizer>& pc_viewer);

    ~pointcloud_processing();

    void processStep(const sensor_msgs::PointCloud2ConstPtr& cloud_msg);

    void pointProcessor();

    PtCdtr FilterCloud(PtCdtr cloud, float filterRes);

    std::pair<PtCdtr, PtCdtr>
    RansacSegmentPlane(PtCdtr cloud, int maxIterations, float distanceTol);

    std::vector<PtCdtr>EuclidCluster(PtCdtr cloud, float clusterTolerance, int minSize,int maxSize);

    //Parameters



};

void renderPointCloud(pcl::visualization::PCLVisualizer::Ptr& viewer, const PtCdtr& cloud,std::string name);




#endif //SRC_POINTCLOUD_PROCESSING_H
