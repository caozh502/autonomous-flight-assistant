/********************************************************************************
** Form generated from reading UI file 'qt_ros_test.ui'
**
** Created by: Qt User Interface Compiler version 5.12.8
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_QT_ROS_TEST_H
#define UI_QT_ROS_TEST_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QSlider>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_Qt_Ros_Test
{
public:
    QVBoxLayout *verticalLayout_2;
    QHBoxLayout *horizontalLayout_2;
    QVBoxLayout *verticalLayout;
    QSpacerItem *verticalSpacer;
    QHBoxLayout *horizontalLayout;
    QLabel *label;
    QLineEdit *lineEdit;
    QSpacerItem *verticalSpacer_2;
    QSpacerItem *horizontalSpacer;
    QSlider *verticalSlider;
    QSpacerItem *horizontalSpacer_2;

    void setupUi(QWidget *Qt_Ros_Test)
    {
        if (Qt_Ros_Test->objectName().isEmpty())
            Qt_Ros_Test->setObjectName(QString::fromUtf8("Qt_Ros_Test"));
        Qt_Ros_Test->resize(450, 250);
        verticalLayout_2 = new QVBoxLayout(Qt_Ros_Test);
        verticalLayout_2->setSpacing(6);
        verticalLayout_2->setContentsMargins(11, 11, 11, 11);
        verticalLayout_2->setObjectName(QString::fromUtf8("verticalLayout_2"));
        horizontalLayout_2 = new QHBoxLayout();
        horizontalLayout_2->setSpacing(6);
        horizontalLayout_2->setObjectName(QString::fromUtf8("horizontalLayout_2"));
        verticalLayout = new QVBoxLayout();
        verticalLayout->setSpacing(6);
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        verticalSpacer = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout->addItem(verticalSpacer);

        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setSpacing(6);
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        label = new QLabel(Qt_Ros_Test);
        label->setObjectName(QString::fromUtf8("label"));

        horizontalLayout->addWidget(label);

        lineEdit = new QLineEdit(Qt_Ros_Test);
        lineEdit->setObjectName(QString::fromUtf8("lineEdit"));
        lineEdit->setEnabled(false);

        horizontalLayout->addWidget(lineEdit);


        verticalLayout->addLayout(horizontalLayout);

        verticalSpacer_2 = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout->addItem(verticalSpacer_2);


        horizontalLayout_2->addLayout(verticalLayout);

        horizontalSpacer = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_2->addItem(horizontalSpacer);

        verticalSlider = new QSlider(Qt_Ros_Test);
        verticalSlider->setObjectName(QString::fromUtf8("verticalSlider"));
        verticalSlider->setValue(20);
        verticalSlider->setOrientation(Qt::Vertical);

        horizontalLayout_2->addWidget(verticalSlider);

        horizontalSpacer_2 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_2->addItem(horizontalSpacer_2);


        verticalLayout_2->addLayout(horizontalLayout_2);


        retranslateUi(Qt_Ros_Test);

        QMetaObject::connectSlotsByName(Qt_Ros_Test);
    } // setupUi

    void retranslateUi(QWidget *Qt_Ros_Test)
    {
        Qt_Ros_Test->setWindowTitle(QApplication::translate("Qt_Ros_Test", "Qt_Ros_Test", nullptr));
        label->setText(QApplication::translate("Qt_Ros_Test", "Publisher:", nullptr));
    } // retranslateUi

};

namespace Ui {
    class Qt_Ros_Test: public Ui_Qt_Ros_Test {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_QT_ROS_TEST_H
