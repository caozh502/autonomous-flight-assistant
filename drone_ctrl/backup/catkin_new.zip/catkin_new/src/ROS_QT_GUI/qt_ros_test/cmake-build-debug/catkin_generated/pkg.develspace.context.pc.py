# generated from catkin/cmake/template/pkg.context.pc.in
CATKIN_PACKAGE_PREFIX = ""
PROJECT_PKG_CONFIG_INCLUDE_DIRS = "/home/caleb/catkin_new/src/ROS_QT_GUI/qt_ros_test/include".split(';') if "/home/caleb/catkin_new/src/ROS_QT_GUI/qt_ros_test/include" != "" else []
PROJECT_CATKIN_DEPENDS = "roscpp;std_msgs".replace(';', ' ')
PKG_CONFIG_LIBRARIES_WITH_PREFIX = "".split(';') if "" != "" else []
PROJECT_NAME = "qt_ros_test"
PROJECT_SPACE_DIR = "/home/caleb/catkin_new/src/ROS_QT_GUI/qt_ros_test/cmake-build-debug/devel"
PROJECT_VERSION = "0.0.0"
