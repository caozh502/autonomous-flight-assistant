//
// Created by caleb on 12.05.21.
//

#include "pointcloud_processing.h"


typedef pcl::PointXYZRGB PointT;
typedef pcl::PointCloud<PointT>::Ptr PtCdtr;


pointcloud_processing::pointcloud_processing(boost::shared_ptr<pcl::visualization::PCLVisualizer>& pc_viewer)
        : nh(), point_sub(), gps_sub()
{
    viewer = pc_viewer;
    gps_sub = nh.subscribe("dji_sdk/gps_position", 1, &pointcloud_processing::gpsCallback,this);
    point_sub = nh.subscribe("/drone/front_camera/depth/points", 1,
                             &pointcloud_processing::processStep, this);
}


pointcloud_processing::~pointcloud_processing(){}



void pointcloud_processing::processStep(const sensor_msgs::PointCloud2ConstPtr& cloud_msg){
    PtCdtr inputCloud(new pcl::PointCloud<PointT>);
    pcl::fromROSMsg (*cloud_msg, *inputCloud);
    sensor_msgs::PointCloud2::Ptr clusters (new sensor_msgs::PointCloud2);
    ////Initialize Parameter

    //Filter
    float filterRes = 0.2;
    //Segmentation
    float distanceThreshold = 0.15;
    int maxIterations = 40;
    //Clustering
    float clusterTolerance = 1;
    int minsize = 30;
    int maxsize = 50000;

    //// 1st:Filter cloud to reduce amount of points
    PtCdtr filteredCloud = FilterCloud(inputCloud, filterRes);
    //// 2nd: Segment the filtered cloud into obstacles and road
    if (current_gps.altitude < (init_gps.altitude+3.1)) {
        std::pair<PtCdtr, PtCdtr> segmentCloud = RansacSegmentPlane(filteredCloud, maxIterations, distanceThreshold);
        renderPointCloud(viewer, segmentCloud.first, "planeCloud");
        //// 3rd: Cluster different obstacle cloud
        cloudClusters = EuclidCluster(segmentCloud.second, clusterTolerance, minsize, maxsize);
    } else{
        cloudClusters = EuclidCluster(filteredCloud, clusterTolerance, minsize, maxsize);
    }

//    pcl::toROSMsg (*cloudClusters , *clusters);
//    pub.publish (*clusters);
}

PtCdtr pointcloud_processing::FilterCloud(PtCdtr cloud, float filterRes){
    auto startTime = std::chrono::steady_clock::now();

    PtCdtr cloud_filtered(new pcl::PointCloud<PointT>);
    PtCdtr cloud_condi(new pcl::PointCloud<PointT>);

    pcl::ConditionAnd<PointT>::Ptr range_cond(new pcl::ConditionAnd<PointT>);
    // 添加比较对象
    range_cond->addComparison(pcl::FieldComparison<PointT>::ConstPtr(new pcl::FieldComparison<PointT>(
            "z", pcl::ComparisonOps::GT, 0.0)));
    range_cond->addComparison(pcl::FieldComparison<PointT>::ConstPtr(new pcl::FieldComparison<PointT>(
            "z", pcl::ComparisonOps::LE, 15.0)));
    range_cond->addComparison(pcl::FieldComparison<PointT>::ConstPtr(new pcl::FieldComparison<PointT>(
            "x", pcl::ComparisonOps::GT, -5)));
    range_cond->addComparison(pcl::FieldComparison<PointT>::ConstPtr(new pcl::FieldComparison<PointT>(
            "x", pcl::ComparisonOps::LE, 5)));
    range_cond->addComparison(pcl::FieldComparison<PointT>::ConstPtr(new pcl::FieldComparison<PointT>(
            "y", pcl::ComparisonOps::GT, -3)));
    range_cond->addComparison(pcl::FieldComparison<PointT>::ConstPtr(new pcl::FieldComparison<PointT>(
            "y", pcl::ComparisonOps::LE, 3)));
    pcl::ConditionalRemoval<PointT> condRem;
    condRem.setInputCloud(cloud);
    // 设置过滤条件
    condRem.setCondition(range_cond);
    // true：将条件之外的点还保留，但是设置NAN, 或者setUserFilterValue修改
    condRem.setKeepOrganized(false);
    condRem.filter(*cloud_condi);

    //VoxelGrid filter
    pcl::VoxelGrid<PointT> vox;
    vox.setInputCloud(cloud_condi);
    vox.setLeafSize(filterRes,filterRes,filterRes);//体素网格大小
    vox.filter(*cloud_filtered);

    auto endTime = std::chrono::steady_clock::now();
    auto elapsedTime = std::chrono::duration_cast<std::chrono::milliseconds>(endTime - startTime);
//    ROS_INFO_STREAM("before filter :"<<cloud->points.size());
//    ROS_INFO_STREAM("after filter :" << cloud_filtered->points.size());
    ROS_INFO_STREAM( "filtering took " << elapsedTime.count() << " ms");

    return cloud_filtered;
}

std::pair<PtCdtr, PtCdtr>
pointcloud_processing::RansacSegmentPlane(PtCdtr cloud, int maxIterations, float distanceTol){
    auto startTime = std::chrono::steady_clock::now();
    PtCdtr out_plane(new pcl::PointCloud<PointT>());
    PtCdtr in_plane(new pcl::PointCloud<PointT>());


    //创建分割时所需要的模型系数对象，coefficients及存储内点的点索引集合对象inliers
    pcl::ModelCoefficients::Ptr coefficients(new pcl::ModelCoefficients);
    pcl::PointIndices::Ptr inliers(new pcl::PointIndices);
    // 创建分割对象
    pcl::SACSegmentation<PointT> seg;
    // 可选择配置，设置模型系数需要优化
    seg.setOptimizeCoefficients(true);
    // 必要的配置，设置分割的模型类型，所用的随机参数估计方法，距离阀值，输入点云
    seg.setModelType(pcl::SACMODEL_PLANE);
    seg.setMethodType(pcl::SAC_RANSAC);
    // you can modify the parameter below
    seg.setMaxIterations(maxIterations);
    seg.setDistanceThreshold(distanceTol);
    seg.setInputCloud(cloud);
    //引发分割实现，存储分割结果到点几何inliers及存储平面模型的系数coefficients
    seg.segment(*inliers, *coefficients);
    if (inliers->indices.size() == 0)
    {
        cout<<"error! Could not found any inliers!"<<endl;
    }
    // extract ground
    pcl::ExtractIndices<PointT> extractor;
    extractor.setInputCloud(cloud);
    extractor.setIndices(inliers);
    extractor.setNegative(true);
    extractor.filter(*out_plane);
    extractor.setNegative(false);
    extractor.filter(*in_plane);
    // vise-versa, remove the ground not just extract the ground
    // just setNegative to be true


    auto endTime = std::chrono::steady_clock::now();
    auto elapsedTime = std::chrono::duration_cast<std::chrono::milliseconds>(endTime - startTime);
    ROS_INFO_STREAM( "Ground removal took " << elapsedTime.count() << " ms");

    return std::pair<PtCdtr, PtCdtr>(in_plane, out_plane);
}

std::vector<PtCdtr>
pointcloud_processing::EuclidCluster(PtCdtr cloud, float clusterTolerance, int minSize,int maxSize){
    auto startTime = std::chrono::steady_clock::now();
    // Search Method: KdTree
    typename pcl::search::KdTree<PointT>::Ptr tree(new pcl::search::KdTree<PointT>);
    tree->setInputCloud(cloud);

    std::vector<pcl::PointIndices> cluster_indices;
    // Euclidean Cluster
    pcl::EuclideanClusterExtraction<PointT> ec;
    ec.setClusterTolerance(clusterTolerance); // 设置空间聚类误差
    ec.setMinClusterSize(minSize);  // 设置有效聚类包含的最小的个数
    ec.setMaxClusterSize(maxSize);  // 设置有效聚类包含的最大的个数
    ec.setSearchMethod(tree);  // 设置搜索方法
    ec.setInputCloud(cloud);
    ec.extract(cluster_indices);  // 获取切割之后的聚类索引保存到cluster_indices
    std::vector<PtCdtr> clusters;
    // For each cluster indices
    for (pcl::PointIndices getIndices: cluster_indices){
        PtCdtr cloud_cluster(new pcl::PointCloud<PointT>);
        // For each point indices in each cluster
        for (int index:getIndices.indices){
            cloud_cluster->points.push_back(cloud->points[index]);}
        cloud_cluster->width = cloud_cluster->points.size();
        cloud_cluster->height = 1;
        cloud_cluster->is_dense = true;
        clusters.push_back(cloud_cluster);
    }

    auto endTime = std::chrono::steady_clock::now();
    auto elapsedTime = std::chrono::duration_cast<std::chrono::milliseconds>(endTime - startTime);
    ROS_INFO_STREAM( "Clustering took " << elapsedTime.count() << " ms and found " << clusters.size() << " clusters");
    return clusters;
}

void pointcloud_processing::gpsCallback(const sensor_msgs::NavSatFix::ConstPtr& msg){
    if (gps_state == 0) { init_gps = *msg; gps_state = 1;}
    current_gps = *msg;
}
void pointcloud_processing::renderPointCloud(pcl::visualization::PCLVisualizer::Ptr& viewer, const  PtCdtr& cloud, std::string name){
    viewer->addPointCloud<PointT> (cloud, name);
    viewer->setPointCloudRenderingProperties (pcl::visualization::PCL_VISUALIZER_COLOR, 0, 0.5, 0, name);
}


