#include "abstract_module.h"

abstract_module::abstract_module() {
}
