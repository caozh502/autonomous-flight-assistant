//
// Created by caleb on 17.05.21.
//

#include "direction_decision.h"
#include "CollisionDetection.h"


//#define C_EARTH (double)6378137.0
//#define C_PI (double)3.141592653589793
//#define DEG2RAD(DEG) ((DEG) * ((C_PI) / (180.0)))

const float speed = 0.2;
int td_counter = 0; // down counter
const std::vector<Color> colors = {Color(1, 0, 0), Color(0, 1, 0), Color(0, 0, 1)};
const int color_bar[][3] =
        {
                { 255,0,0},
                { 0,255,0 },
                { 0,0,255 },
                { 0,255,255 },
                { 255,255,0 },
                { 255,255,255 },
                { 255,0,255 }
        };
//TODO: cloudClusters in message rewrite (reference drone_object_ros.cpp)
std::vector<PtCdtr> cloudClusters;
pcl::visualization::PCLVisualizer::Ptr viewer;
//Mission square_mission;

// global variables for subscribed topics
sensor_msgs::NavSatFix current_gps;
geometry_msgs::Quaternion current_atti;


direction_decision::direction_decision(DroneObjectROS &drone)
    : nh(), gpsSub(), my_drone(drone),
    target_x(0.0), target_y(0.0), target_z(0.0),
    drone_x(0.0), drone_y(0.0), drone_z(0.0), drone_yaw(0.0)
{
    attiSub = nh.subscribe("dji_sdk/attitude", 1, &direction_decision::attitude_callback,this);
    gpsSub = nh.subscribe("dji_sdk/gps_position", 1, &direction_decision::motionStep,this);
    setTarget(49.01348,8.40670,-9.70000);
}


direction_decision::~direction_decision(){}

void direction_decision::motionStep(const sensor_msgs::NavSatFix::ConstPtr& msg) {

    ////get Angle between drone heading vector and drone2Target vector
    current_gps = *msg;
    ROS_INFO("GPS: lat=%.5f, long=%.5f", msg->latitude, msg->longitude);
    setDronePos(current_gps.latitude,current_gps.longitude,current_gps.altitude,
                toEulerAngle(current_atti).z);
    //angle_ro: angle for drone to aim to target
    float angle_ro=getAimAngle();
    ROS_INFO("you need rotate %.5f rad, yawRad = %.5f", angle_ro, drone_yaw);

    ////TODO: turn to target (just at very beginning)
    //drone_rotation(angle_ro);

    int clusterId = 0;
    ////create box for drone
    Eigen::Vector3f uav_point1(-1, -0.25, 3);
    //Eigen::Vector3f uav_point2(-15,1,2);
    float length_1 = uav_point1(2);
    float width_1 = -2 * uav_point1(0);

    //float length_2=2*uav_point2(2);
    //float width_2=-2*uav_point2(0);

    float height = -2 * uav_point1(1);

    Box droneBox = createBox(uav_point1, width_1, length_1, height);
    //Box uav_2 = CreateBox(uav_point2,width_2,length_2,height);
    UAVBoxVisualization(viewer, droneBox, colors[1], clusterId);

    if (cloudClusters.empty()){
        //std::cout<<"cannot get clusters!"<<std::endl;
        drone_forward(0.1);
        clusterId++;
        return;
    }
    for (const PtCdtr &cluster : cloudClusters) {

        pcl::visualization::PointCloudColorHandlerCustom<PointT> cloud_in_color_h(cluster,
                                                                                  color_bar[clusterId][0],
                                                                                  color_bar[clusterId][1],
                                                                                  color_bar[clusterId][2]);//赋予显示点云的颜色
//        pcl::visualization::PointCloudColorHandlerRandom<PointT> cloud_in_color_h(cluster);
        viewer->addPointCloud<PointT>(cluster, cloud_in_color_h, "cluster" + std::to_string(clusterId));

        //// 4th: Find bounding boxes for each obstacle cluster
        Box box = BoundingBox(cluster);
        renderBox(viewer, box, clusterId);

        //// 5th: Collision Detection && Direction Decision

        if (isCollision(box, droneBox)) {
            ROS_INFO( "***** find collision on the path *****" );
            viewer->removeShape("uav" + std::to_string(clusterId));
            CollisionVisualization(viewer, droneBox, colors[0], clusterId);

            motionCtrl(box, td_counter);
            clusterId++;
            break;
        }

        if (td_counter == 3) {
            drone_forward(1.5);
            ROS_INFO( "***** Rise to the original height *****" );
            //stop -> turn up -> stop
            drone_stop(1.0);
            drone_updown(0.5 * td_counter);
            drone_stop(1.0);
            td_counter = 0;
        } else {
            drone_forward(0.3);
        }

        ////TODO: turn to target again, go ahead

        clusterId++;
    }
}

void direction_decision::motionCtrl(Box box, int &td_counter) {
    if (box.y_max >= -0.5 && box.y_max <= 0.5) {
        ROS_INFO( "***** turn down *****" );
        //stop -> turn down -> stop
        drone_stop(1.0);
        drone_updown(-0.5);
        drone_stop(1.0);
        td_counter++;
        return;
    }
    if ((box.x_min + box.x_max) / 2 >= 0) {
        ROS_INFO("***** turn left *****" );
        //stop -> turn left -> stop
        drone_stop(1.0);
        drone_rotation(0.5);
        drone_stop(1.0);

    } else {
        ROS_INFO( "***** turn right *****");
        //stop -> turn right -> stop
        drone_stop(1.0);
        drone_rotation(-0.5);
        drone_stop(1.0);
    }
}

void direction_decision::drone_forward(float time){
    my_drone.pitch(speed);
    ros::Duration(time).sleep();
}

void direction_decision::drone_stop(float time){
    my_drone.hover();
    ros::Duration(time).sleep();
}

void direction_decision::drone_rotation(float time){
    //plus: turn left; minus: turn right
    my_drone.yaw(time/fabs(time)*speed);
    ros::Duration(fabs(time)).sleep();
}

void direction_decision::drone_updown(float time){
    //plus: turn up; minus: turn down
    my_drone.rise(time/fabs(time)*speed);
    ros::Duration(fabs(time)).sleep();
}

void direction_decision::setTarget(float x, float y, float z){
    target_x=x;
    target_y=y;
    target_z=z;
    std::cout<<"set target successfully!"<<std::endl;
}

void direction_decision::setDronePos(double x, double y, double z, double yaw){
    drone_x=x;
    drone_y=y;
    drone_z=z;
    drone_yaw=yaw;
    std::cout<<"set drone position successfully!"<<std::endl;
}

float direction_decision::getAimAngle(){
    //drone_v: drone heading vector
    float drone_v[2] = {cos(drone_yaw), sin(drone_yaw)};
    //drone2tar_v: drone -> target point vector
    float drone2tar_v[2] = {(target_x - drone_x, target_y - drone_y)};
    float target_v[2] = {target_x,target_y};

    float drone_v2[2] = {drone_x+cos(drone_yaw),drone_y+sin(drone_yaw)} ;
    float angle_diff= getAngle(drone_v,drone2tar_v);
    float turn_sign = judgeTurnDirection(drone_v, drone_v2, target_v);

    return turn_sign*angle_diff;

}

float direction_decision::judgeTurnDirection(const float *pos1, const float *pos2, const float *target){
    float c=(pos2[0]-pos1[0])*(target[1]-pos1[1])-(pos2[1]-pos1[1])*(target[0]-pos1[0]);
    if (c>0) return 1.0;
    else return -1.0;
}

float direction_decision::getAngle(const float *v1, const float *v2){
    float x1=v1[0]; float y1=v1[1];
    float x2=v2[0]; float y2=v2[1];
    float v1_length= getLength(v1);
    float v2_length= getLength(v2);
    float cos_angle = (x1 * x2 + y1 * y2) / (v1_length * v2_length);
    return acos(cos_angle);
}

float direction_decision::getLength(const float *v) {
    return (sqrt(pow(v[0],2)+pow(v[1],2)));
}

geometry_msgs::Vector3 direction_decision::toEulerAngle(geometry_msgs::Quaternion quat)
{
    geometry_msgs::Vector3 ans;

    tf::Matrix3x3 R_FLU2ENU(tf::Quaternion(quat.x, quat.y, quat.z, quat.w));
    R_FLU2ENU.getRPY(ans.x, ans.y, ans.z);
    return ans;
}

void direction_decision::attitude_callback(const geometry_msgs::QuaternionStamped::ConstPtr& msg)
{
    current_atti = msg->quaternion;
}

Box BoundingBox(PtCdtr cluster) {

    // Find bounding box for one of the clusters
    PointT minPoint, maxPoint;
    pcl::getMinMax3D(*cluster, minPoint, maxPoint);

    Box box;
    box.x_min = minPoint.x;
    box.y_min = minPoint.y;
    box.z_min = minPoint.z;
    box.x_max = maxPoint.x;
    box.y_max = maxPoint.y;
    box.z_max = maxPoint.z;

    return box;
}

void renderBox(pcl::visualization::PCLVisualizer::Ptr& viewer, Box box, int id){
    std::string cube = "box"+std::to_string(id);
    viewer->addCube(box.x_min, box.x_max, box.y_min, box.y_max, box.z_min, box.z_max, 1, 0, 0, cube);
    viewer->setShapeRenderingProperties(pcl::visualization::PCL_VISUALIZER_REPRESENTATION, pcl::visualization::PCL_VISUALIZER_REPRESENTATION_WIREFRAME, cube);
}