//
// Created by caleb on 17.05.21.
//

#ifndef DRONE_CTRL_DIRECTION_DECISION_H
#define DRONE_CTRL_DIRECTION_DECISION_H


#include <cmath>
#include <sstream>
// ROS includes
#include "ros/ros.h"
#include "../../include/drone_object_ros.h"
#include "std_msgs/String.h"

#include <sensor_msgs/NavSatFix.h>

#include <tf/tf.h>
#include <sensor_msgs/Joy.h>
#include "abstract_module.h"
#include "pointcloud_processing.h"




class Mission
{
public:
    // The basic state transition flow is:
    // 0---> 1 ---> 2 ---> ... ---> N ---> 0
    // where state 0 means the mission is note started
    // and each state i is for the process of moving to a target point.
    int state;

    int inbound_counter;
    int outbound_counter;
    int break_counter;

    float target_offset_x;
    float target_offset_y;
    float target_offset_z;
    float target_yaw;
    sensor_msgs::NavSatFix start_gps_location;
    geometry_msgs::Point start_local_position;

    bool finished;

    Mission() : state(0), inbound_counter(0), outbound_counter(0), break_counter(0),
                target_offset_x(0.0), target_offset_y(0.0), target_offset_z(0.0),
                finished(false)
    {
    }

    void step();

    void setTarget(float x, float y, float z, float yaw)
    {
        target_offset_x = x;
        target_offset_y = y;
        target_offset_z = z;
        target_yaw      = yaw;
    }

    void reset()
    {
        inbound_counter = 0;
        outbound_counter = 0;
        break_counter = 0;
        finished = false;
    }

};

class direction_decision : public abstract_module {
    ros::NodeHandle nh;
    ros::Publisher pub;
    ros::Subscriber gpsSub;
    ros::Subscriber attiSub;
    DroneObjectROS my_drone;
public:

    direction_decision(DroneObjectROS &drone);

    ~direction_decision();

    void motionStep(const sensor_msgs::NavSatFix::ConstPtr &msg);// Global planning

    void motionCtrl(Box box,int &td_counter);//when isCollision==true, make the motion decision

    void drone_forward(float time);

    void drone_stop(float time);

    void drone_rotation(float time);

    void drone_updown(float time);

    void setTarget(float x, float y, float z);

    void setDronePos(double x, double y, double z, double yaw);

    float getAimAngle();

    float judgeTurnDirection(const float *pos1, const float *pos2, const float *target);

    float getAngle(const float *v1, const float *v2);

    float getLength(const float *v);

    geometry_msgs::Vector3 toEulerAngle(geometry_msgs::Quaternion quat);

    void attitude_callback(const geometry_msgs::QuaternionStamped::ConstPtr &msg);

    //parameters
    float target_x;
    float target_y;
    float target_z;
    float drone_x;
    float drone_y;
    float drone_z;
    float drone_yaw;
};

void renderBox(pcl::visualization::PCLVisualizer::Ptr& viewer, Box box, int id);

Box BoundingBox(PtCdtr cluster);

#endif //DRONE_CTRL_DIRECTION_DECISION_H
